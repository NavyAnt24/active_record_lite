require_relative './rails_lite/controller_base'
require_relative './rails_lite/router'
