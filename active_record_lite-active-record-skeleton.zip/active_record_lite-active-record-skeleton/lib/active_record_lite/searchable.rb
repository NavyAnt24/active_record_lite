require_relative './db_connection'

module Searchable
  def where(params)
  end
end